using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Modal2;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GestaoNucleos
{
    public partial class Form1 : Form
    {
        private Panel currentPanel;

        public Form1()
        {
            InitializeComponent();
            currentPanel = panel8;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TestDBConnection(textBox1.Text, textBox2.Text, textBox2.Text, textBox3.Text + ";encrypt=false");
        }

        private void TestDBConnection(string dbServer, string dbName, string userName, string userPass)
        {
            SqlConnection CN = new SqlConnection("Data Source = " + dbServer + " ;" + "Initial Catalog = " + dbName + "; uid = " + userName + ";" + "password = " + userPass);

            try
            {
                CN.Open();
                if (CN.State == ConnectionState.Open)
                {
                    MessageBox.Show("Successful connection to database " + CN.Database + " on the " + CN.DataSource + " server", "Connection Test", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to open connection to the database due to the error \r\n" + ex.Message, "Connection Test", MessageBoxButtons.OK);
            }

            if (CN.State == ConnectionState.Open)
                CN.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if the database connection is established
            if (IsDatabaseConnected(textBox1.Text, textBox2.Text, textBox2.Text, textBox3.Text + ";encrypt=false"))
            {
                panel4.Visible = true;

                ShowPanel(panel4);
            }
            else
            {
                // Database connection is not established, show an error message
                MessageBox.Show("Database connection is not established. Please check your connection parameters.", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            currentPanel = panel4;
            panel17.Hide();
            panel6.Hide();
            panel15.Hide();
            panel20.Hide();
            panel11.Hide();
            panel4.Visible = true;
            ShowPanel(panel4);
        }


        private void button4_Click(object sender, EventArgs e)
        {
            currentPanel = panel6;
            panel17.Hide();
            panel4.Hide();
            panel15.Hide();
            panel20.Hide();
            panel11.Hide();
            panel6.Show();
            panel6.Visible = true;
            ShowPanel(panel6);
        }

        private void label6_Click(object sender, EventArgs e)
        {
            currentPanel = panel15;
            panel17.Hide();
            panel4.Hide();
            panel6.Hide();
            panel20.Hide();
            panel15.Show();
            panel15.Visible = true;
            ShowPanel(panel15);
        }

        private void ShowPanel(Panel panel)
        {
            // Hide the current panel
            currentPanel.Visible = false;

            // Show the new panel
            panel.Visible = true;

            // Update the current panel reference
            currentPanel = panel;
        }

        private bool IsDatabaseConnected(string dbServer, string dbName, string userName, string userPass)
        {
            using (SqlConnection CN = new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";uid=" + userName + ";password=" + userPass))
            {
                try
                {
                    CN.Open();
                    return CN.State == ConnectionState.Open;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel8.Visible = true;
            panel8.BringToFront();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand("Relatorios", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to the DataGridView
                    dataGridView1.DataSource = dataTable;


                    panel8.SendToBack();
                    panel4.BringToFront();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Get the name filter value from textBox4
                    string filterName = textBox4.Text;

                    // Create a SqlCommand object to execute the stored procedure
                    SqlCommand command = new SqlCommand("Relatorios", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@FilterNome", filterName);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the filtered DataTable to the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Create a SqlCommand object to retrieve the data from the UDF
                    SqlCommand command = new SqlCommand("SELECT * FROM dbo.GetEventosMonetInfo2()", connection);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to dataGridView2
                    dataGridView2.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to retrieve data from the UDF.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            int numero;
            if (int.TryParse(textBox5.Text, out numero))
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";
                string storedProcedureName = "dbo.VerLucroTotal";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@numero", numero);

                        connection.Open();
                        object result = command.ExecuteScalar();
                        connection.Close();

                        if (result != null && result != DBNull.Value)
                        {
                            decimal total = Convert.ToDecimal(result);
                            label16.Text = string.Format("Total: {0:C2}", total);
                        }
                        else
                        {
                            label16.Text = "Total: N/A";
                        }
                    }
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int numero;
            if (int.TryParse(textBox5.Text, out numero))
            {
                string connectionString = "Data Source=SERVER_NAME;Initial Catalog=p10g5;Integrated Security=True";
                string storedProcedureName = "dbo.VerLucroTotal";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@numero", numero);

                        connection.Open();
                        decimal total = (decimal)command.ExecuteScalar();
                        connection.Close();

                        label16.Text = string.Format("Total: {0:C2}", total);
                    }
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            EliminarTrabalhador aem = new EliminarTrabalhador();
            aem.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Create a SqlCommand object to execute the UDF
                    SqlCommand command = new SqlCommand("SELECT * FROM dbo.GetEventosNaoMonetarios()", connection);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to dataGridView3
                    dataGridView3.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to retrieve data from the UDF.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            string sponsorCC = textBox6.Text.Trim();
            if (!string.IsNullOrEmpty(sponsorCC))
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        if (connection.State == ConnectionState.Closed)
                        {
                            connection.Open();
                        }

                        // Create a SqlCommand object to retrieve the sponsor's information
                        SqlCommand command = new SqlCommand("SELECT nome, email, telemovel FROM GestaoNucleos.Pessoa WHERE n_CC = @sponsorCC", connection);
                        command.Parameters.AddWithValue("@sponsorCC", sponsorCC);

                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            // Display the sponsor's information in the respective labels
                            label20.Text = reader["nome"].ToString();
                            label26.Text = reader["email"].ToString();
                            label28.Text = reader["telemovel"].ToString();
                        }
                        else
                        {
                            // Clear the labels if no sponsor with the given CC number is found
                            label20.Text = "";
                            label26.Text = "";
                            label28.Text = "";
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to retrieve sponsor information.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Clear the labels if the sponsor CC number is empty
                label20.Text = "";
                label26.Text = "";
                label28.Text = "";
            }
        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Create a SqlCommand object to execute the query
                    SqlCommand command = new SqlCommand("SELECT n_CC, nome, n_horas FROM dbo.GetTrabalhadorInfo()", connection);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to dataGridView4
                    dataGridView4.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to retrieve Trabalhador information.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Get the name filter value from textBox9
                    string filterName = textBox9.Text.Trim();

                    // Create a SqlCommand object to execute the stored procedure
                    SqlCommand command = new SqlCommand("dbo.SearchTrabalhadorInfo", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@searchName", filterName);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the filtered DataTable to the DataGridView
                    dataGridView4.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Create a SqlCommand object to execute the stored procedure
                    SqlCommand command = new SqlCommand("GetPulseiraDetails", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to dataGridView5
                    dataGridView5.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView6_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    int eventoNumero;
                    if (int.TryParse(textBox7.Text, out eventoNumero))
                    {
                        // Create a SqlCommand object to execute the stored procedure
                        SqlCommand command = new SqlCommand("VerPulseiraPorEvento", connection);
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@evento_numero", eventoNumero);

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the DataTable to dataGridView6
                        dataGridView6.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteVerBebidasStoredProcedure()
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Create a SqlCommand object to execute the stored procedure
                    SqlCommand command = new SqlCommand("VerBebidas", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to dataGridView7
                    dataGridView7.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteVerComidaStoredProcedure()
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Create a SqlCommand object to execute the stored procedure
                    SqlCommand command = new SqlCommand("VerComida", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to dataGridView8
                    dataGridView8.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void button19_Click(object sender, EventArgs e)
        {
            ExecuteVerComidaStoredProcedure();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            ExecuteVerBebidasStoredProcedure();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Modal1 modal1 = new Modal1();
            modal1.ShowDialog();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            EliminarTrabalhador et = new EliminarTrabalhador();
            et.ShowDialog();
        }


        private void label6_Click_1(object sender, EventArgs e)
        {
            currentPanel = panel15;
            panel17.Hide();
            panel4.Hide();
            panel6.Hide();
            panel20.Hide();
            panel11.Hide();
            panel8.Hide();
            panel15.Show();
            panel15.Visible = true;
            panel15.BringToFront();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            currentPanel = panel17;
            panel4.Hide();
            panel6.Hide();
            panel15.Hide();
            panel20.Hide();
            panel11.Hide();
            panel17.Show();
            panel8.Hide();
            panel17.Visible = true;
            panel17.BringToFront();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            currentPanel = panel20;
            panel17.Hide();
            panel4.Hide();
            panel6.Hide();
            panel15.Hide();
            panel11.Hide();
            panel20.Show();
            panel8.Hide();
            panel20.Visible = true;
            panel20.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            currentPanel = panel11;
            panel17.Hide();
            panel4.Hide();
            panel6.Hide();
            panel15.Hide();
            panel20.Hide();
            panel11.Show();
            panel8.Hide();
            panel11.Visible = true;
            panel11.BringToFront();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Open the database connection
                    connection.Open();

                    // Create a SqlCommand object to execute the query
                    SqlCommand command = new SqlCommand("SELECT dbo.ContarBebidas() AS CountBebidas", connection);

                    // Execute the query and retrieve the count
                    int countBebidas = (int)command.ExecuteScalar();

                    // Update label45 with the count of beverages
                    label45.Text = "Count of Beverages: " + countBebidas.ToString();
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that may occur during the database operations
                MessageBox.Show("Failed to retrieve the count of beverages.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Open the database connection
                    connection.Open();

                    // Create a SqlCommand object to execute the query
                    SqlCommand command = new SqlCommand("SELECT dbo.ContarAlimentacao() AS CountAlimentacao", connection);

                    // Execute the query and retrieve the count
                    int countAlimentacao = (int)command.ExecuteScalar();

                    // Update label45 with the count of food
                    label44.Text = "Count of Food: " + countAlimentacao.ToString();
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that may occur during the database operations
                MessageBox.Show("Failed to retrieve the count of food.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}