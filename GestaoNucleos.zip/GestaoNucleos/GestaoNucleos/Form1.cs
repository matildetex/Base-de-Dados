using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GestaoNucleos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TestDBConnection(textBox1.Text, textBox2.Text, textBox2.Text, textBox3.Text + ";encrypt=false");
        }

        private void TestDBConnection(string dbServer, string dbName, string userName, string userPass)
        {
            SqlConnection CN = new SqlConnection("Data Source = " + dbServer + " ;" + "Initial Catalog = " + dbName + "; uid = " + userName + ";" + "password = " + userPass);

            try
            {
                CN.Open();
                if (CN.State == ConnectionState.Open)
                {
                    MessageBox.Show("Successful connection to database " + CN.Database + " on the " + CN.DataSource + " server", "Connection Test", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to open connection to the database due to the error \r\n" + ex.Message, "Connection Test", MessageBoxButtons.OK);
            }

            if (CN.State == ConnectionState.Open)
                CN.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if the database connection is established
            if (IsDatabaseConnected(textBox1.Text, textBox2.Text, textBox2.Text, textBox3.Text + ";encrypt=false"))
            {
                // Database connection is established, navigate to panel4
                panel4.Visible = true;
                panel4.BringToFront();
            }
            else
            {
                // Database connection is not established, show an error message
                MessageBox.Show("Database connection is not established. Please check your connection parameters.", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsDatabaseConnected(string dbServer, string dbName, string userName, string userPass)
        {
            using (SqlConnection CN = new SqlConnection("Data Source=" + dbServer + ";Initial Catalog=" + dbName + ";uid=" + userName + ";password=" + userPass))
            {
                try
                {
                    CN.Open();
                    return CN.State == ConnectionState.Open;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel8.Visible = true;
            panel8.BringToFront();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand("Relatorios", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to the DataGridView
                    dataGridView1.DataSource = dataTable;

                    panel8.SendToBack();
                    panel4.BringToFront();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            panel4.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
            panel6.BringToFront();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Get the name filter value from textBox4
                    string filterName = textBox4.Text;

                    // Create a SqlCommand object to execute the stored procedure
                    SqlCommand command = new SqlCommand("Relatorios", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@FilterNome", filterName);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the filtered DataTable to the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to execute the stored procedure.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Create a SqlCommand object to retrieve the data from the UDF
                    SqlCommand command = new SqlCommand("SELECT * FROM dbo.GetEventosMonetInfo2()", connection);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Bind the DataTable to dataGridView2
                    dataGridView2.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to retrieve data from the UDF.\n\nError message: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            int numero;
            if (int.TryParse(textBox5.Text, out numero))
            {
                string connectionString = "Data Source=" + textBox1.Text + ";Initial Catalog=" + textBox2.Text + ";uid=" + textBox2.Text + ";password=" + textBox3.Text + ";encrypt=false";
                string storedProcedureName = "dbo.VerLucroTotal";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@numero", numero);

                        connection.Open();
                        object result = command.ExecuteScalar();
                        connection.Close();

                        if (result != null && result != DBNull.Value)
                        {
                            decimal total = Convert.ToDecimal(result);
                            label16.Text = string.Format("Total: {0:C2}", total);
                        }
                        else
                        {
                            label16.Text = "Total: N/A";
                        }
                    }
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int numero;
            if (int.TryParse(textBox5.Text, out numero))
            {
                string connectionString = "Data Source=SERVER_NAME;Initial Catalog=p10g5;Integrated Security=True";
                string storedProcedureName = "dbo.VerLucroTotal";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@numero", numero);

                        connection.Open();
                        decimal total = (decimal)command.ExecuteScalar();
                        connection.Close();

                        label16.Text = string.Format("Total: {0:C2}", total);
                    }
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            AdicionarEventoMonetario aem = new AdicionarEventoMonetario();
            aem.Show();
        }
    }
}