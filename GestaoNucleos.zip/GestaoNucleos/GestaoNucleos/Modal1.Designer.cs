﻿namespace Modal2
{
    partial class Modal1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label_addeventonaomonetario = new Label();
            label_numeroevento = new Label();
            label_nomevento = new Label();
            label_local = new Label();
            label_tipo = new Label();
            label_area = new Label();
            label_npart = new Label();
            label_ntrab = new Label();
            pictureBox1 = new PictureBox();
            label_data = new Label();
            label_sponsorCC = new Label();
            label_tipoSponsor = new Label();
            textBox_nomevento = new TextBox();
            textBox_local = new TextBox();
            numericUpDown_participantes = new NumericUpDown();
            numericUpDown_trab = new NumericUpDown();
            dateTimePicker_data = new DateTimePicker();
            textBox_sponsorCC = new TextBox();
            comboBox_tiposponsor = new ComboBox();
            comboBox_tipo = new ComboBox();
            comboBox_area = new ComboBox();
            button_addeventoNaoMon = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_participantes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_trab).BeginInit();
            SuspendLayout();
            // 
            // label_addeventonaomonetario
            // 
            label_addeventonaomonetario.AutoSize = true;
            label_addeventonaomonetario.BackColor = Color.Green;
            label_addeventonaomonetario.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label_addeventonaomonetario.ForeColor = SystemColors.ButtonFace;
            label_addeventonaomonetario.Location = new Point(45, 64);
            label_addeventonaomonetario.Margin = new Padding(4, 0, 4, 0);
            label_addeventonaomonetario.Name = "label_addeventonaomonetario";
            label_addeventonaomonetario.Size = new Size(449, 38);
            label_addeventonaomonetario.TabIndex = 0;
            label_addeventonaomonetario.Text = "Adicionar Evento Não Monetário";
            label_addeventonaomonetario.Click += label1_Click;
            // 
            // label_numeroevento
            // 
            label_numeroevento.AutoSize = true;
            label_numeroevento.Location = new Point(45, 170);
            label_numeroevento.Margin = new Padding(4, 0, 4, 0);
            label_numeroevento.Name = "label_numeroevento";
            label_numeroevento.Size = new Size(382, 25);
            label_numeroevento.TabIndex = 1;
            label_numeroevento.Text = "Número Evento (adicionado automaticamente)";
            label_numeroevento.Click += label_numeroevento_Click;
            // 
            // label_nomevento
            // 
            label_nomevento.AutoSize = true;
            label_nomevento.Location = new Point(45, 239);
            label_nomevento.Margin = new Padding(4, 0, 4, 0);
            label_nomevento.Name = "label_nomevento";
            label_nomevento.Size = new Size(120, 25);
            label_nomevento.TabIndex = 2;
            label_nomevento.Text = "Nome Evento";
            label_nomevento.Click += label_nomevento_Click;
            // 
            // label_local
            // 
            label_local.AutoSize = true;
            label_local.Location = new Point(45, 299);
            label_local.Margin = new Padding(4, 0, 4, 0);
            label_local.Name = "label_local";
            label_local.Size = new Size(52, 25);
            label_local.TabIndex = 3;
            label_local.Text = "Local";
            // 
            // label_tipo
            // 
            label_tipo.AutoSize = true;
            label_tipo.Location = new Point(45, 365);
            label_tipo.Margin = new Padding(4, 0, 4, 0);
            label_tipo.Name = "label_tipo";
            label_tipo.Size = new Size(47, 25);
            label_tipo.TabIndex = 4;
            label_tipo.Text = "Tipo";
            // 
            // label_area
            // 
            label_area.AutoSize = true;
            label_area.Location = new Point(45, 431);
            label_area.Margin = new Padding(4, 0, 4, 0);
            label_area.Name = "label_area";
            label_area.Size = new Size(48, 25);
            label_area.TabIndex = 5;
            label_area.Text = "Área";
            // 
            // label_npart
            // 
            label_npart.AutoSize = true;
            label_npart.Location = new Point(491, 170);
            label_npart.Margin = new Padding(4, 0, 4, 0);
            label_npart.Name = "label_npart";
            label_npart.Size = new Size(181, 25);
            label_npart.TabIndex = 6;
            label_npart.Text = "Número Participantes";
            // 
            // label_ntrab
            // 
            label_ntrab.AutoSize = true;
            label_ntrab.Location = new Point(491, 239);
            label_ntrab.Margin = new Padding(4, 0, 4, 0);
            label_ntrab.Name = "label_ntrab";
            label_ntrab.Size = new Size(192, 25);
            label_ntrab.TabIndex = 7;
            label_ntrab.Text = "Número Trabalhadores";
            label_ntrab.Click += label8_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Green;
            pictureBox1.Location = new Point(2, 15);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1001, 119);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label_data
            // 
            label_data.AutoSize = true;
            label_data.Location = new Point(491, 299);
            label_data.Margin = new Padding(4, 0, 4, 0);
            label_data.Name = "label_data";
            label_data.Size = new Size(49, 25);
            label_data.TabIndex = 9;
            label_data.Text = "Data";
            // 
            // label_sponsorCC
            // 
            label_sponsorCC.AutoSize = true;
            label_sponsorCC.Location = new Point(494, 358);
            label_sponsorCC.Margin = new Padding(4, 0, 4, 0);
            label_sponsorCC.Name = "label_sponsorCC";
            label_sponsorCC.Size = new Size(139, 25);
            label_sponsorCC.TabIndex = 10;
            label_sponsorCC.Text = "Patrocinador CC";
            // 
            // label_tipoSponsor
            // 
            label_tipoSponsor.AutoSize = true;
            label_tipoSponsor.Location = new Point(494, 431);
            label_tipoSponsor.Margin = new Padding(4, 0, 4, 0);
            label_tipoSponsor.Name = "label_tipoSponsor";
            label_tipoSponsor.Size = new Size(152, 25);
            label_tipoSponsor.TabIndex = 11;
            label_tipoSponsor.Text = "Patrocinador Tipo";
            // 
            // textBox_nomevento
            // 
            textBox_nomevento.Location = new Point(192, 239);
            textBox_nomevento.Margin = new Padding(4);
            textBox_nomevento.Name = "textBox_nomevento";
            textBox_nomevento.Size = new Size(245, 31);
            textBox_nomevento.TabIndex = 13;
            textBox_nomevento.TextChanged += textBox_nomevento_TextChanged;
            // 
            // textBox_local
            // 
            textBox_local.Location = new Point(108, 295);
            textBox_local.Margin = new Padding(4);
            textBox_local.Name = "textBox_local";
            textBox_local.Size = new Size(330, 31);
            textBox_local.TabIndex = 14;
            // 
            // numericUpDown_participantes
            // 
            numericUpDown_participantes.Location = new Point(688, 170);
            numericUpDown_participantes.Margin = new Padding(4);
            numericUpDown_participantes.Name = "numericUpDown_participantes";
            numericUpDown_participantes.Size = new Size(216, 31);
            numericUpDown_participantes.TabIndex = 15;
            // 
            // numericUpDown_trab
            // 
            numericUpDown_trab.Location = new Point(700, 236);
            numericUpDown_trab.Margin = new Padding(4);
            numericUpDown_trab.Name = "numericUpDown_trab";
            numericUpDown_trab.Size = new Size(204, 31);
            numericUpDown_trab.TabIndex = 16;
            // 
            // dateTimePicker_data
            // 
            dateTimePicker_data.Location = new Point(550, 295);
            dateTimePicker_data.Margin = new Padding(4);
            dateTimePicker_data.Name = "dateTimePicker_data";
            dateTimePicker_data.Size = new Size(353, 31);
            dateTimePicker_data.TabIndex = 17;
            // 
            // textBox_sponsorCC
            // 
            textBox_sponsorCC.Location = new Point(649, 358);
            textBox_sponsorCC.Margin = new Padding(4);
            textBox_sponsorCC.Name = "textBox_sponsorCC";
            textBox_sponsorCC.Size = new Size(254, 31);
            textBox_sponsorCC.TabIndex = 18;
            // 
            // comboBox_tiposponsor
            // 
            comboBox_tiposponsor.AutoCompleteCustomSource.AddRange(new string[] { "Financial Partner", "Strategical Partner", "In-Kind Partner", "Product Partner", "Media Partner" });
            comboBox_tiposponsor.AutoCompleteMode = AutoCompleteMode.Suggest;
            comboBox_tiposponsor.FormattingEnabled = true;
            comboBox_tiposponsor.Items.AddRange(new object[] { "Financial Partner", "Strategical Partner", "In-Kind Partner", "Product Partner", "Media Partner" });
            comboBox_tiposponsor.Location = new Point(660, 428);
            comboBox_tiposponsor.Margin = new Padding(4);
            comboBox_tiposponsor.Name = "comboBox_tiposponsor";
            comboBox_tiposponsor.Size = new Size(243, 33);
            comboBox_tiposponsor.TabIndex = 19;
            // 
            // comboBox_tipo
            // 
            comboBox_tipo.AutoCompleteCustomSource.AddRange(new string[] { "Workshop", "Palestra", "Sessão de Dúvidas", "Evento Cultural", "Conferência" });
            comboBox_tipo.FormattingEnabled = true;
            comboBox_tipo.Items.AddRange(new object[] { "Workshop", "Palestra", "Sessão de Dúvidas", "Evento Cultural", "Conferência" });
            comboBox_tipo.Location = new Point(108, 365);
            comboBox_tipo.Margin = new Padding(4);
            comboBox_tipo.Name = "comboBox_tipo";
            comboBox_tipo.Size = new Size(330, 33);
            comboBox_tipo.TabIndex = 20;
            // 
            // comboBox_area
            // 
            comboBox_area.AutoCompleteCustomSource.AddRange(new string[] { "Pedagógica", "Desportiva", "Cultural", "Comunicação", "Imagem" });
            comboBox_area.FormattingEnabled = true;
            comboBox_area.Items.AddRange(new object[] { "Pedagógica", "Desportiva", "Cultural", "Comunicação", "Imagem" });
            comboBox_area.Location = new Point(108, 431);
            comboBox_area.Margin = new Padding(4);
            comboBox_area.Name = "comboBox_area";
            comboBox_area.Size = new Size(330, 33);
            comboBox_area.TabIndex = 21;
            // 
            // button_addeventoNaoMon
            // 
            button_addeventoNaoMon.BackColor = Color.Green;
            button_addeventoNaoMon.ForeColor = SystemColors.ButtonFace;
            button_addeventoNaoMon.Location = new Point(352, 495);
            button_addeventoNaoMon.Margin = new Padding(4);
            button_addeventoNaoMon.Name = "button_addeventoNaoMon";
            button_addeventoNaoMon.Size = new Size(315, 36);
            button_addeventoNaoMon.TabIndex = 22;
            button_addeventoNaoMon.Text = "Adicionar Evento Não Monetário";
            button_addeventoNaoMon.UseVisualStyleBackColor = false;
            button_addeventoNaoMon.Click += button_addeventoNaoMon_Click;
            // 
            // Modal1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 562);
            Controls.Add(button_addeventoNaoMon);
            Controls.Add(comboBox_area);
            Controls.Add(comboBox_tipo);
            Controls.Add(comboBox_tiposponsor);
            Controls.Add(textBox_sponsorCC);
            Controls.Add(dateTimePicker_data);
            Controls.Add(numericUpDown_trab);
            Controls.Add(numericUpDown_participantes);
            Controls.Add(textBox_local);
            Controls.Add(textBox_nomevento);
            Controls.Add(label_tipoSponsor);
            Controls.Add(label_sponsorCC);
            Controls.Add(label_data);
            Controls.Add(label_ntrab);
            Controls.Add(label_npart);
            Controls.Add(label_area);
            Controls.Add(label_tipo);
            Controls.Add(label_local);
            Controls.Add(label_nomevento);
            Controls.Add(label_numeroevento);
            Controls.Add(label_addeventonaomonetario);
            Controls.Add(pictureBox1);
            Margin = new Padding(4);
            Name = "Modal1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_participantes).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_trab).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label_addeventonaomonetario;
        private Label label_numeroevento;
        private Label label_nomevento;
        private Label label_local;
        private Label label_tipo;
        private Label label_area;
        private Label label_npart;
        private Label label_ntrab;
        private PictureBox pictureBox1;
        private Label label_data;
        private Label label_sponsorCC;
        private Label label_tipoSponsor;
        private TextBox textBox_nomevento;
        private TextBox textBox_local;
        private NumericUpDown numericUpDown_participantes;
        private NumericUpDown numericUpDown_trab;
        private DateTimePicker dateTimePicker_data;
        private TextBox textBox_sponsorCC;
        private ComboBox comboBox_tiposponsor;
        private ComboBox comboBox_tipo;
        private ComboBox comboBox_area;
        private Button button_addeventoNaoMon;
    }
}