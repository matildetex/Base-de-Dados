﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace GestaoNucleos
{
    public partial class EliminarTrabalhador : Form
    {
        public EliminarTrabalhador()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label_numeroevento_Click(object sender, EventArgs e)
        {

        }

        private void AdicionarEventoMonetario_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox_nevento_TextChanged(object sender, EventArgs e)
        {
            string connectionString = "Data Source= mednat.ieeta.pt\\SQLSERVER,8101;Initial Catalog= p10g5;uid= p10g5;password=Rissois4@rroz;encrypt=false";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string n_CC = textBox_nevento.Text;

                    // Assuming you have a database connection named "connection" established
                    SqlCommand command = new SqlCommand("SELECT nome, morada, telemovel, email, n_horas FROM GestaoNucleos.Pessoa p JOIN GestaoNucleos.Trabalhadores t ON p.n_CC = t.n_CC WHERE p.n_CC = @n_CC", connection);
                    command.Parameters.AddWithValue("@n_CC", n_CC);


                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        textBox_nomevento.Text = reader["nome"].ToString();
                        textBox2.Text = reader["morada"].ToString();
                        textBox4.Text = reader["telemovel"].ToString(); // int
                        textBox3.Text = reader["email"].ToString();
                        textBox1.Text = reader["n_horas"].ToString(); // float
                    }
                    else
                    {
                        // If the CC number is not found, clear the fields
                        textBox_nomevento.Text = "";
                        textBox2.Text = "";
                        textBox4.Text = "";
                        textBox3.Text = "";
                        textBox1.Text = "";
                    }

                    reader.Close();

                }
                catch (Exception ex)
                {
                    // Handle any exception that may occur during database operations
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }


        private void textBox_nomevento_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button_addeventoNaoMon_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=mednat.ieeta.pt\\SQLSERVER,8101;Initial Catalog=p10g5;uid=p10g5;password=Rissois4@rroz;encrypt=false";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string n_CC = textBox_nevento.Text;
                    string nome = textBox_nomevento.Text;
                    string telefone = textBox4.Text;
                    string email = textBox3.Text;
                    string morada = textBox2.Text;
                    float horas = float.Parse(textBox1.Text);

                    SqlCommand command = new SqlCommand("UPDATE GestaoNucleos.Trabalhadores SET n_horas = @Horas WHERE n_CC = @NCC", connection);
                    command.Parameters.AddWithValue("@Horas", horas);
                    command.Parameters.AddWithValue("@NCC", n_CC);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Worker information updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("No worker found with the specified CC number.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }


    }
}
