﻿namespace GestaoNucleos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            button2 = new Button();
            button1 = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            panel5 = new Panel();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            pictureBox3 = new PictureBox();
            panel6 = new Panel();
            label17 = new Label();
            button8 = new Button();
            label16 = new Label();
            label14 = new Label();
            textBox5 = new TextBox();
            panel4 = new Panel();
            button7 = new Button();
            label13 = new Label();
            dataGridView1 = new DataGridView();
            textBox4 = new TextBox();
            label11 = new Label();
            button3 = new Button();
            button5 = new Button();
            panel3 = new Panel();
            label9 = new Label();
            button4 = new Button();
            label10 = new Label();
            dataGridView2 = new DataGridView();
            button6 = new Button();
            panel7 = new Panel();
            label12 = new Label();
            contextMenuStrip1 = new ContextMenuStrip(components);
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            sqlCommand2 = new Microsoft.Data.SqlClient.SqlCommand();
            panel8 = new Panel();
            panel9 = new Panel();
            panel10 = new Panel();
            label15 = new Label();
            button9 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel6.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(91, 68);
            panel1.Name = "panel1";
            panel1.Size = new Size(909, 658);
            panel1.TabIndex = 1;
            // 
            // button2
            // 
            button2.BackColor = Color.Green;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = SystemColors.Window;
            button2.Location = new Point(476, 553);
            button2.Name = "button2";
            button2.Size = new Size(151, 49);
            button2.TabIndex = 16;
            button2.Text = "Entrar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(0, 192, 0);
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = SystemColors.Window;
            button1.Location = new Point(295, 553);
            button1.Name = "button1";
            button1.Size = new Size(151, 49);
            button1.TabIndex = 15;
            button1.Text = "Conectar à BD";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Franklin Gothic Medium", 25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(327, 161);
            label4.Name = "label4";
            label4.Size = new Size(273, 63);
            label4.TabIndex = 14;
            label4.Text = "Bem Vindo!";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(222, 440);
            label3.Name = "label3";
            label3.Size = new Size(87, 25);
            label3.TabIndex = 13;
            label3.Text = "Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(262, 374);
            label2.Name = "label2";
            label2.Size = new Size(47, 25);
            label2.TabIndex = 12;
            label2.Text = "User";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(247, 305);
            label1.Name = "label1";
            label1.Size = new Size(61, 25);
            label1.TabIndex = 11;
            label1.Text = "Server";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(315, 437);
            textBox3.Name = "textBox3";
            textBox3.PasswordChar = '*';
            textBox3.Size = new Size(339, 31);
            textBox3.TabIndex = 10;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(315, 371);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(339, 31);
            textBox2.TabIndex = 9;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(315, 302);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(339, 31);
            textBox1.TabIndex = 8;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.nei_imagem;
            pictureBox2.Location = new Point(327, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(265, 115);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(panel5);
            panel2.Controls.Add(pictureBox3);
            panel2.Location = new Point(6, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(1407, 824);
            panel2.TabIndex = 17;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.BackgroundImage = (Image)resources.GetObject("panel5.BackgroundImage");
            panel5.Controls.Add(label5);
            panel5.Controls.Add(label6);
            panel5.Controls.Add(label7);
            panel5.Controls.Add(label8);
            panel5.Location = new Point(0, 104);
            panel5.Name = "panel5";
            panel5.Size = new Size(186, 720);
            panel5.TabIndex = 18;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(58, 124);
            label5.Name = "label5";
            label5.Size = new Size(95, 30);
            label5.TabIndex = 17;
            label5.Text = "Eventos";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(56, 311);
            label6.Name = "label6";
            label6.Size = new Size(100, 30);
            label6.TabIndex = 18;
            label6.Text = "Workers";
            label6.TextAlign = ContentAlignment.TopCenter;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(53, 491);
            label7.Name = "label7";
            label7.Size = new Size(108, 30);
            label7.TabIndex = 19;
            label7.Text = "Pulseiras";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(51, 669);
            label8.Name = "label8";
            label8.Size = new Size(111, 30);
            label8.TabIndex = 20;
            label8.Text = "Armazém";
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.Image = Properties.Resources.nei_imagem;
            pictureBox3.Location = new Point(-25, -31);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(363, 181);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 17;
            pictureBox3.TabStop = false;
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(button9);
            panel6.Controls.Add(label15);
            panel6.Controls.Add(panel10);
            panel6.Controls.Add(panel9);
            panel6.Controls.Add(label17);
            panel6.Controls.Add(button8);
            panel6.Controls.Add(label16);
            panel6.Controls.Add(label14);
            panel6.Controls.Add(textBox5);
            panel6.Controls.Add(label10);
            panel6.Controls.Add(dataGridView2);
            panel6.Controls.Add(button6);
            panel6.Controls.Add(panel7);
            panel6.Location = new Point(336, 9);
            panel6.Name = "panel6";
            panel6.Size = new Size(1077, 824);
            panel6.TabIndex = 27;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.Black;
            label17.Location = new Point(560, 627);
            label17.Name = "label17";
            label17.Size = new Size(128, 30);
            label17.TabIndex = 26;
            label17.Text = "Lucro final:";
            // 
            // button8
            // 
            button8.Location = new Point(430, 668);
            button8.Name = "button8";
            button8.Size = new Size(108, 34);
            button8.TabIndex = 25;
            button8.Text = "Pesquisar";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label16.Location = new Point(560, 673);
            label16.Name = "label16";
            label16.Size = new Size(36, 25);
            label16.TabIndex = 24;
            label16.Text = "???";
            label16.Click += label16_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(29, 674);
            label14.Name = "label14";
            label14.Size = new Size(81, 25);
            label14.TabIndex = 17;
            label14.Text = "Numero:";
            // 
            // textBox5
            // 
            textBox5.BackColor = SystemColors.ControlDark;
            textBox5.Location = new Point(116, 671);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(277, 31);
            textBox5.TabIndex = 17;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(button7);
            panel4.Controls.Add(label13);
            panel4.Controls.Add(dataGridView1);
            panel4.Controls.Add(textBox4);
            panel4.Controls.Add(label11);
            panel4.Controls.Add(button3);
            panel4.Controls.Add(button5);
            panel4.Controls.Add(panel3);
            panel4.Controls.Add(button4);
            panel4.Location = new Point(336, 859);
            panel4.Name = "panel4";
            panel4.Size = new Size(1077, 824);
            panel4.TabIndex = 19;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(0, 192, 0);
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button7.ForeColor = Color.Transparent;
            button7.Location = new Point(528, 167);
            button7.Name = "button7";
            button7.Size = new Size(106, 34);
            button7.TabIndex = 27;
            button7.Text = "Procurar";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(32, 170);
            label13.Name = "label13";
            label13.Size = new Size(137, 25);
            label13.TabIndex = 18;
            label13.Text = "Procurar Evento";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(29, 210);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1021, 340);
            dataGridView1.TabIndex = 19;
            // 
            // textBox4
            // 
            textBox4.BackColor = SystemColors.ActiveBorder;
            textBox4.Location = new Point(175, 167);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(339, 31);
            textBox4.TabIndex = 17;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(431, 677);
            label11.Name = "label11";
            label11.Size = new Size(197, 23);
            label11.TabIndex = 26;
            label11.Text = "Escolher tipo do Evento:";
            // 
            // button3
            // 
            button3.Location = new Point(440, 565);
            button3.Name = "button3";
            button3.Size = new Size(173, 34);
            button3.TabIndex = 20;
            button3.Text = "Atualizar Eventos";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click_1;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(0, 192, 0);
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button5.ForeColor = Color.Transparent;
            button5.Location = new Point(550, 723);
            button5.Name = "button5";
            button5.Size = new Size(222, 55);
            button5.TabIndex = 25;
            button5.Text = "Eventos Não Monetários";
            button5.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.BackgroundImage = Properties.Resources.top_folder;
            panel3.Controls.Add(label9);
            panel3.Location = new Point(29, 28);
            panel3.Name = "panel3";
            panel3.Size = new Size(1021, 77);
            panel3.TabIndex = 22;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(20, 17);
            label9.Name = "label9";
            label9.Size = new Size(139, 42);
            label9.TabIndex = 21;
            label9.Text = "Eventos";
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(0, 192, 0);
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button4.ForeColor = Color.Transparent;
            button4.Location = new Point(287, 723);
            button4.Name = "button4";
            button4.Size = new Size(222, 55);
            button4.TabIndex = 24;
            button4.Text = "Eventos Monetários";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(29, 623);
            label10.Name = "label10";
            label10.Size = new Size(388, 30);
            label10.TabIndex = 21;
            label10.Text = "Lucro final de um Evento Monetário:";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(29, 167);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.Size = new Size(1021, 340);
            dataGridView2.TabIndex = 19;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // button6
            // 
            button6.Location = new Point(440, 522);
            button6.Name = "button6";
            button6.Size = new Size(173, 34);
            button6.TabIndex = 20;
            button6.Text = "Atualizar Eventos";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Transparent;
            panel7.BackgroundImage = Properties.Resources.top_folder;
            panel7.Controls.Add(label12);
            panel7.Location = new Point(29, 28);
            panel7.Name = "panel7";
            panel7.Size = new Size(1021, 77);
            panel7.TabIndex = 22;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.White;
            label12.Location = new Point(20, 17);
            label12.Name = "label12";
            label12.Size = new Size(322, 42);
            label12.TabIndex = 21;
            label12.Text = "Eventos Monetários";
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // sqlCommand2
            // 
            sqlCommand2.CommandTimeout = 30;
            sqlCommand2.EnableOptimizedParameterBinding = false;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Transparent;
            panel8.BackgroundImage = Properties.Resources.graidient1;
            panel8.Controls.Add(panel1);
            panel8.Location = new Point(1449, 15);
            panel8.Name = "panel8";
            panel8.Size = new Size(1074, 827);
            panel8.TabIndex = 17;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Transparent;
            panel9.BackgroundImage = Properties.Resources.top_folder;
            panel9.Location = new Point(29, 598);
            panel9.Name = "panel9";
            panel9.Size = new Size(1021, 10);
            panel9.TabIndex = 23;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Transparent;
            panel10.BackgroundImage = Properties.Resources.top_folder;
            panel10.Location = new Point(29, 722);
            panel10.Name = "panel10";
            panel10.Size = new Size(1021, 10);
            panel10.TabIndex = 24;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor = Color.Black;
            label15.Location = new Point(29, 763);
            label15.Name = "label15";
            label15.Size = new Size(299, 30);
            label15.TabIndex = 27;
            label15.Text = "Adicionar Evento Monetário";
            // 
            // button9
            // 
            button9.Location = new Point(349, 759);
            button9.Name = "button9";
            button9.Size = new Size(108, 34);
            button9.TabIndex = 28;
            button9.Text = "Adicionar";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(2355, 1001);
            Controls.Add(panel8);
            Controls.Add(panel6);
            Controls.Add(panel2);
            Controls.Add(panel4);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel8.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label4;
        private Button button1;
        private Button button2;
        private Panel panel2;
        private PictureBox pictureBox2;
        private ContextMenuStrip contextMenuStrip1;
        private Label label5;
        private Label label8;
        private Label label7;
        private Label label6;
        private PictureBox pictureBox3;
        private Panel panel5;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand2;
        private Button button3;
        private DataGridView dataGridView1;
        private Label label9;
        private Panel panel3;
        private Label label11;
        private Panel panel4;
        private Panel panel6;
        private DataGridView dataGridView2;
        private Button button6;
        private Panel panel7;
        private Label label12;
        private Button button5;
        private Button button4;
        private Label label10;
        private Panel panel8;
        private Button button7;
        private Label label13;
        private TextBox textBox4;
        private Label label14;
        private TextBox textBox5;
        private Label label16;
        private Label label17;
        private Button button8;
        private Button button9;
        private Label label15;
        private Panel panel10;
        private Panel panel9;
    }
}