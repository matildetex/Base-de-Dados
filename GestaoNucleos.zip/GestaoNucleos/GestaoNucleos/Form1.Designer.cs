﻿namespace GestaoNucleos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            button2 = new Button();
            button1 = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            panel5 = new Panel();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            pictureBox3 = new PictureBox();
            panel6 = new Panel();
            button9 = new Button();
            label15 = new Label();
            panel10 = new Panel();
            panel9 = new Panel();
            label17 = new Label();
            button8 = new Button();
            label16 = new Label();
            label14 = new Label();
            textBox5 = new TextBox();
            label10 = new Label();
            dataGridView2 = new DataGridView();
            button6 = new Button();
            panel7 = new Panel();
            label12 = new Label();
            panel20 = new Panel();
            button24 = new Button();
            button23 = new Button();
            label45 = new Label();
            label44 = new Label();
            button20 = new Button();
            button19 = new Button();
            label40 = new Label();
            label39 = new Label();
            dataGridView8 = new DataGridView();
            button16 = new Button();
            label38 = new Label();
            panel21 = new Panel();
            dataGridView7 = new DataGridView();
            panel22 = new Panel();
            label42 = new Label();
            panel11 = new Panel();
            label29 = new Label();
            panel12 = new Panel();
            label27 = new Label();
            label28 = new Label();
            label25 = new Label();
            label26 = new Label();
            label24 = new Label();
            button10 = new Button();
            label18 = new Label();
            panel13 = new Panel();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            textBox6 = new TextBox();
            label22 = new Label();
            dataGridView3 = new DataGridView();
            button12 = new Button();
            panel14 = new Panel();
            label23 = new Label();
            panel4 = new Panel();
            panel8 = new Panel();
            button7 = new Button();
            label13 = new Label();
            dataGridView1 = new DataGridView();
            textBox4 = new TextBox();
            label11 = new Label();
            button3 = new Button();
            button5 = new Button();
            panel3 = new Panel();
            label9 = new Label();
            button4 = new Button();
            panel17 = new Panel();
            button18 = new Button();
            label37 = new Label();
            panel19 = new Panel();
            label32 = new Label();
            dataGridView6 = new DataGridView();
            textBox7 = new TextBox();
            label36 = new Label();
            label31 = new Label();
            dataGridView5 = new DataGridView();
            button17 = new Button();
            panel18 = new Panel();
            label33 = new Label();
            panel15 = new Panel();
            button22 = new Button();
            button21 = new Button();
            button11 = new Button();
            label30 = new Label();
            dataGridView4 = new DataGridView();
            textBox9 = new TextBox();
            label34 = new Label();
            button13 = new Button();
            button14 = new Button();
            panel16 = new Panel();
            label35 = new Label();
            button15 = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            sqlCommand2 = new Microsoft.Data.SqlClient.SqlCommand();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            panel7.SuspendLayout();
            panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView7).BeginInit();
            panel22.SuspendLayout();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            panel14.SuspendLayout();
            panel4.SuspendLayout();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel3.SuspendLayout();
            panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            panel18.SuspendLayout();
            panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            panel16.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(91, 68);
            panel1.Name = "panel1";
            panel1.Size = new Size(909, 658);
            panel1.TabIndex = 1;
            // 
            // button2
            // 
            button2.BackColor = Color.Green;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = SystemColors.Window;
            button2.Location = new Point(476, 553);
            button2.Name = "button2";
            button2.Size = new Size(151, 49);
            button2.TabIndex = 16;
            button2.Text = "Entrar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(0, 192, 0);
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = SystemColors.Window;
            button1.Location = new Point(295, 553);
            button1.Name = "button1";
            button1.Size = new Size(151, 49);
            button1.TabIndex = 15;
            button1.Text = "Conectar à BD";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Franklin Gothic Medium", 25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(327, 161);
            label4.Name = "label4";
            label4.Size = new Size(273, 63);
            label4.TabIndex = 14;
            label4.Text = "Bem Vindo!";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(222, 440);
            label3.Name = "label3";
            label3.Size = new Size(87, 25);
            label3.TabIndex = 13;
            label3.Text = "Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(262, 374);
            label2.Name = "label2";
            label2.Size = new Size(47, 25);
            label2.TabIndex = 12;
            label2.Text = "User";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(247, 305);
            label1.Name = "label1";
            label1.Size = new Size(61, 25);
            label1.TabIndex = 11;
            label1.Text = "Server";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(315, 437);
            textBox3.Name = "textBox3";
            textBox3.PasswordChar = '*';
            textBox3.Size = new Size(339, 31);
            textBox3.TabIndex = 10;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(315, 371);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(339, 31);
            textBox2.TabIndex = 9;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(315, 302);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(339, 31);
            textBox1.TabIndex = 8;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.nei_imagem;
            pictureBox2.Location = new Point(327, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(265, 115);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(panel5);
            panel2.Controls.Add(pictureBox3);
            panel2.Location = new Point(6, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(326, 824);
            panel2.TabIndex = 17;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.BackgroundImage = (Image)resources.GetObject("panel5.BackgroundImage");
            panel5.Controls.Add(label5);
            panel5.Controls.Add(label6);
            panel5.Controls.Add(label7);
            panel5.Controls.Add(label8);
            panel5.Location = new Point(0, 104);
            panel5.Name = "panel5";
            panel5.Size = new Size(186, 720);
            panel5.TabIndex = 18;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(58, 124);
            label5.Name = "label5";
            label5.Size = new Size(95, 30);
            label5.TabIndex = 17;
            label5.Text = "Eventos";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(56, 311);
            label6.Name = "label6";
            label6.Size = new Size(100, 30);
            label6.TabIndex = 18;
            label6.Text = "Workers";
            label6.TextAlign = ContentAlignment.TopCenter;
            label6.Click += label6_Click_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(53, 491);
            label7.Name = "label7";
            label7.Size = new Size(108, 30);
            label7.TabIndex = 19;
            label7.Text = "Pulseiras";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(51, 669);
            label8.Name = "label8";
            label8.Size = new Size(111, 30);
            label8.TabIndex = 20;
            label8.Text = "Armazém";
            label8.Click += label8_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.Image = Properties.Resources.nei_imagem;
            pictureBox3.Location = new Point(-25, -31);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(363, 181);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 17;
            pictureBox3.TabStop = false;
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(button9);
            panel6.Controls.Add(label15);
            panel6.Controls.Add(panel10);
            panel6.Controls.Add(panel9);
            panel6.Controls.Add(label17);
            panel6.Controls.Add(button8);
            panel6.Controls.Add(label16);
            panel6.Controls.Add(label14);
            panel6.Controls.Add(textBox5);
            panel6.Controls.Add(label10);
            panel6.Controls.Add(dataGridView2);
            panel6.Controls.Add(button6);
            panel6.Controls.Add(panel7);
            panel6.Location = new Point(350, 12);
            panel6.Name = "panel6";
            panel6.Size = new Size(1077, 824);
            panel6.TabIndex = 27;
            // 
            // button9
            // 
            button9.Location = new Point(349, 759);
            button9.Name = "button9";
            button9.Size = new Size(108, 34);
            button9.TabIndex = 28;
            button9.Text = "Adicionar";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor = Color.Black;
            label15.Location = new Point(29, 763);
            label15.Name = "label15";
            label15.Size = new Size(299, 30);
            label15.TabIndex = 27;
            label15.Text = "Adicionar Evento Monetário";
            // 
            // panel10
            // 
            panel10.BackColor = Color.Transparent;
            panel10.BackgroundImage = Properties.Resources.top_folder;
            panel10.Location = new Point(29, 722);
            panel10.Name = "panel10";
            panel10.Size = new Size(1021, 10);
            panel10.TabIndex = 24;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Transparent;
            panel9.BackgroundImage = Properties.Resources.top_folder;
            panel9.Location = new Point(29, 598);
            panel9.Name = "panel9";
            panel9.Size = new Size(1021, 10);
            panel9.TabIndex = 23;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.Black;
            label17.Location = new Point(560, 627);
            label17.Name = "label17";
            label17.Size = new Size(128, 30);
            label17.TabIndex = 26;
            label17.Text = "Lucro final:";
            // 
            // button8
            // 
            button8.Location = new Point(430, 668);
            button8.Name = "button8";
            button8.Size = new Size(108, 34);
            button8.TabIndex = 25;
            button8.Text = "Pesquisar";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label16.Location = new Point(560, 673);
            label16.Name = "label16";
            label16.Size = new Size(36, 25);
            label16.TabIndex = 24;
            label16.Text = "???";
            label16.Click += label16_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(29, 674);
            label14.Name = "label14";
            label14.Size = new Size(81, 25);
            label14.TabIndex = 17;
            label14.Text = "Numero:";
            // 
            // textBox5
            // 
            textBox5.BackColor = SystemColors.ControlDark;
            textBox5.Location = new Point(116, 671);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(277, 31);
            textBox5.TabIndex = 17;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(29, 623);
            label10.Name = "label10";
            label10.Size = new Size(388, 30);
            label10.TabIndex = 21;
            label10.Text = "Lucro final de um Evento Monetário:";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(29, 167);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.Size = new Size(1021, 340);
            dataGridView2.TabIndex = 19;
            // 
            // button6
            // 
            button6.Location = new Point(440, 522);
            button6.Name = "button6";
            button6.Size = new Size(173, 34);
            button6.TabIndex = 20;
            button6.Text = "Atualizar Eventos";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Transparent;
            panel7.BackgroundImage = Properties.Resources.top_folder;
            panel7.Controls.Add(label12);
            panel7.Location = new Point(29, 28);
            panel7.Name = "panel7";
            panel7.Size = new Size(1021, 77);
            panel7.TabIndex = 22;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.White;
            label12.Location = new Point(20, 17);
            label12.Name = "label12";
            label12.Size = new Size(322, 42);
            label12.TabIndex = 21;
            label12.Text = "Eventos Monetários";
            // 
            // panel20
            // 
            panel20.BackColor = Color.White;
            panel20.Controls.Add(button24);
            panel20.Controls.Add(button23);
            panel20.Controls.Add(label45);
            panel20.Controls.Add(label44);
            panel20.Controls.Add(button20);
            panel20.Controls.Add(button19);
            panel20.Controls.Add(label40);
            panel20.Controls.Add(label39);
            panel20.Controls.Add(dataGridView8);
            panel20.Controls.Add(button16);
            panel20.Controls.Add(label38);
            panel20.Controls.Add(panel21);
            panel20.Controls.Add(dataGridView7);
            panel20.Controls.Add(panel22);
            panel20.Location = new Point(350, 12);
            panel20.Name = "panel20";
            panel20.Size = new Size(1077, 824);
            panel20.TabIndex = 31;
            // 
            // button24
            // 
            button24.Location = new Point(378, 491);
            button24.Name = "button24";
            button24.Size = new Size(117, 34);
            button24.TabIndex = 39;
            button24.Text = "Atualizar";
            button24.UseVisualStyleBackColor = true;
            button24.Click += button24_Click;
            // 
            // button23
            // 
            button23.Location = new Point(896, 495);
            button23.Name = "button23";
            button23.Size = new Size(117, 34);
            button23.TabIndex = 38;
            button23.Text = "Atualizar";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.BackColor = Color.Transparent;
            label45.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label45.ForeColor = Color.Black;
            label45.Location = new Point(556, 497);
            label45.Name = "label45";
            label45.Size = new Size(37, 30);
            label45.TabIndex = 37;
            label45.Text = "??";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.BackColor = Color.Transparent;
            label44.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label44.ForeColor = Color.Black;
            label44.Location = new Point(50, 493);
            label44.Name = "label44";
            label44.Size = new Size(37, 30);
            label44.TabIndex = 36;
            label44.Text = "??";
            // 
            // button20
            // 
            button20.Location = new Point(728, 423);
            button20.Name = "button20";
            button20.Size = new Size(117, 34);
            button20.TabIndex = 33;
            button20.Text = "Atualizar";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button19
            // 
            button19.Location = new Point(204, 423);
            button19.Name = "button19";
            button19.Size = new Size(117, 34);
            button19.TabIndex = 29;
            button19.Text = "Atualizar";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.BackColor = Color.Transparent;
            label40.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label40.ForeColor = Color.Black;
            label40.Location = new Point(553, 192);
            label40.Name = "label40";
            label40.Size = new Size(103, 30);
            label40.TabIndex = 32;
            label40.Text = "Bebidas:";
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.BackColor = Color.Transparent;
            label39.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label39.ForeColor = Color.Black;
            label39.Location = new Point(50, 192);
            label39.Name = "label39";
            label39.Size = new Size(109, 30);
            label39.TabIndex = 31;
            label39.Text = "Comidas:";
            // 
            // dataGridView8
            // 
            dataGridView8.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView8.Location = new Point(46, 229);
            dataGridView8.Name = "dataGridView8";
            dataGridView8.RowHeadersWidth = 62;
            dataGridView8.Size = new Size(453, 177);
            dataGridView8.TabIndex = 30;
            // 
            // button16
            // 
            button16.BackColor = Color.FromArgb(0, 192, 0);
            button16.FlatStyle = FlatStyle.Flat;
            button16.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button16.ForeColor = Color.Transparent;
            button16.Location = new Point(103, 700);
            button16.Name = "button16";
            button16.Size = new Size(222, 55);
            button16.TabIndex = 28;
            button16.Text = "Adicionar produtos";
            button16.UseVisualStyleBackColor = false;
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.BackColor = Color.Transparent;
            label38.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label38.ForeColor = Color.Black;
            label38.Location = new Point(103, 645);
            label38.Name = "label38";
            label38.Size = new Size(214, 30);
            label38.TabIndex = 29;
            label38.Text = "Adicionar produtos:";
            // 
            // panel21
            // 
            panel21.BackColor = Color.Transparent;
            panel21.BackgroundImage = Properties.Resources.top_folder;
            panel21.Location = new Point(28, 599);
            panel21.Name = "panel21";
            panel21.Size = new Size(1021, 10);
            panel21.TabIndex = 24;
            // 
            // dataGridView7
            // 
            dataGridView7.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView7.Location = new Point(550, 229);
            dataGridView7.Name = "dataGridView7";
            dataGridView7.RowHeadersWidth = 62;
            dataGridView7.Size = new Size(453, 177);
            dataGridView7.TabIndex = 29;
            // 
            // panel22
            // 
            panel22.BackColor = Color.Transparent;
            panel22.BackgroundImage = Properties.Resources.top_folder;
            panel22.Controls.Add(label42);
            panel22.Location = new Point(29, 28);
            panel22.Name = "panel22";
            panel22.Size = new Size(1021, 77);
            panel22.TabIndex = 22;
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.BackColor = Color.Transparent;
            label42.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label42.ForeColor = Color.White;
            label42.Location = new Point(20, 17);
            label42.Name = "label42";
            label42.Size = new Size(167, 42);
            label42.TabIndex = 21;
            label42.Text = "Armazém";
            // 
            // panel11
            // 
            panel11.BackColor = Color.White;
            panel11.Controls.Add(label29);
            panel11.Controls.Add(panel12);
            panel11.Controls.Add(label27);
            panel11.Controls.Add(label28);
            panel11.Controls.Add(label25);
            panel11.Controls.Add(label26);
            panel11.Controls.Add(label24);
            panel11.Controls.Add(button10);
            panel11.Controls.Add(label18);
            panel11.Controls.Add(panel13);
            panel11.Controls.Add(label19);
            panel11.Controls.Add(label20);
            panel11.Controls.Add(label21);
            panel11.Controls.Add(textBox6);
            panel11.Controls.Add(label22);
            panel11.Controls.Add(dataGridView3);
            panel11.Controls.Add(button12);
            panel11.Controls.Add(panel14);
            panel11.Location = new Point(350, 12);
            panel11.Name = "panel11";
            panel11.Size = new Size(1077, 824);
            panel11.TabIndex = 29;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.BackColor = Color.Transparent;
            label29.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label29.ForeColor = Color.Black;
            label29.Location = new Point(49, 595);
            label29.Name = "label29";
            label29.Size = new Size(316, 30);
            label29.TabIndex = 34;
            label29.Text = "Atualizar pagamento sponsor";
            // 
            // panel12
            // 
            panel12.BackColor = Color.Transparent;
            panel12.BackgroundImage = Properties.Resources.top_folder;
            panel12.Location = new Point(49, 540);
            panel12.Name = "panel12";
            panel12.Size = new Size(1021, 10);
            panel12.TabIndex = 24;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(627, 390);
            label27.Name = "label27";
            label27.Size = new Size(66, 25);
            label27.TabIndex = 33;
            label27.Text = "Phone:";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label28.Location = new Point(696, 390);
            label28.Name = "label28";
            label28.Size = new Size(36, 25);
            label28.TabIndex = 32;
            label28.Text = "???";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(627, 352);
            label25.Name = "label25";
            label25.Size = new Size(58, 25);
            label25.TabIndex = 31;
            label25.Text = "Email:";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label26.Location = new Point(696, 352);
            label26.Name = "label26";
            label26.Size = new Size(36, 25);
            label26.TabIndex = 30;
            label26.Text = "???";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(627, 314);
            label24.Name = "label24";
            label24.Size = new Size(63, 25);
            label24.TabIndex = 29;
            label24.Text = "Name:";
            // 
            // button10
            // 
            button10.Location = new Point(370, 490);
            button10.Name = "button10";
            button10.Size = new Size(108, 34);
            button10.TabIndex = 28;
            button10.Text = "Adicionar";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.Transparent;
            label18.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = Color.Black;
            label18.Location = new Point(49, 494);
            label18.Name = "label18";
            label18.Size = new Size(299, 30);
            label18.TabIndex = 27;
            label18.Text = "Adicionar Evento Monetário";
            // 
            // panel13
            // 
            panel13.BackColor = Color.Transparent;
            panel13.BackgroundImage = Properties.Resources.top_folder;
            panel13.Location = new Point(49, 460);
            panel13.Name = "panel13";
            panel13.Size = new Size(1021, 10);
            panel13.TabIndex = 23;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Transparent;
            label19.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = Color.Black;
            label19.Location = new Point(627, 265);
            label19.Name = "label19";
            label19.Size = new Size(92, 30);
            label19.TabIndex = 26;
            label19.Text = "Details:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label20.Location = new Point(696, 314);
            label20.Name = "label20";
            label20.Size = new Size(36, 25);
            label20.TabIndex = 24;
            label20.Text = "???";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(630, 223);
            label21.Name = "label21";
            label21.Size = new Size(38, 25);
            label21.TabIndex = 17;
            label21.Text = "CC:";
            // 
            // textBox6
            // 
            textBox6.BackColor = SystemColors.ControlDark;
            textBox6.Location = new Point(686, 220);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(289, 31);
            textBox6.TabIndex = 17;
            textBox6.TextChanged += textBox6_TextChanged;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.BackColor = Color.Transparent;
            label22.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label22.ForeColor = Color.Black;
            label22.Location = new Point(627, 187);
            label22.Name = "label22";
            label22.Size = new Size(180, 30);
            label22.TabIndex = 21;
            label22.Text = "Sponsor details:";
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(49, 210);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 62;
            dataGridView3.Size = new Size(509, 149);
            dataGridView3.TabIndex = 19;
            // 
            // button12
            // 
            button12.Location = new Point(220, 387);
            button12.Name = "button12";
            button12.Size = new Size(173, 34);
            button12.TabIndex = 20;
            button12.Text = "Atualizar Eventos";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // panel14
            // 
            panel14.BackColor = Color.Transparent;
            panel14.BackgroundImage = Properties.Resources.top_folder;
            panel14.Controls.Add(label23);
            panel14.Location = new Point(29, 28);
            panel14.Name = "panel14";
            panel14.Size = new Size(1021, 77);
            panel14.TabIndex = 22;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.BackColor = Color.Transparent;
            label23.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label23.ForeColor = Color.White;
            label23.Location = new Point(20, 17);
            label23.Name = "label23";
            label23.Size = new Size(392, 42);
            label23.TabIndex = 21;
            label23.Text = "Eventos Não Monetários";
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(panel8);
            panel4.Controls.Add(button7);
            panel4.Controls.Add(label13);
            panel4.Controls.Add(dataGridView1);
            panel4.Controls.Add(textBox4);
            panel4.Controls.Add(label11);
            panel4.Controls.Add(button3);
            panel4.Controls.Add(button5);
            panel4.Controls.Add(panel3);
            panel4.Controls.Add(button4);
            panel4.Location = new Point(350, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(1077, 824);
            panel4.TabIndex = 19;
            // 
            // panel8
            // 
            panel8.BackColor = Color.WhiteSmoke;
            panel8.BackgroundImage = Properties.Resources.graidient1;
            panel8.Controls.Add(panel1);
            panel8.Location = new Point(6, 3);
            panel8.Name = "panel8";
            panel8.Size = new Size(1074, 824);
            panel8.TabIndex = 17;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(0, 192, 0);
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button7.ForeColor = Color.Transparent;
            button7.Location = new Point(528, 167);
            button7.Name = "button7";
            button7.Size = new Size(106, 34);
            button7.TabIndex = 27;
            button7.Text = "Procurar";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(32, 170);
            label13.Name = "label13";
            label13.Size = new Size(137, 25);
            label13.TabIndex = 18;
            label13.Text = "Procurar Evento";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(29, 210);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1021, 340);
            dataGridView1.TabIndex = 19;
            // 
            // textBox4
            // 
            textBox4.BackColor = SystemColors.ActiveBorder;
            textBox4.Location = new Point(175, 167);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(339, 31);
            textBox4.TabIndex = 17;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(431, 677);
            label11.Name = "label11";
            label11.Size = new Size(197, 23);
            label11.TabIndex = 26;
            label11.Text = "Escolher tipo do Evento:";
            // 
            // button3
            // 
            button3.Location = new Point(440, 565);
            button3.Name = "button3";
            button3.Size = new Size(173, 34);
            button3.TabIndex = 20;
            button3.Text = "Atualizar Eventos";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click_1;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(0, 192, 0);
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button5.ForeColor = Color.Transparent;
            button5.Location = new Point(550, 723);
            button5.Name = "button5";
            button5.Size = new Size(222, 55);
            button5.TabIndex = 25;
            button5.Text = "Eventos Não Monetários";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.BackgroundImage = Properties.Resources.top_folder;
            panel3.Controls.Add(label9);
            panel3.Location = new Point(29, 28);
            panel3.Name = "panel3";
            panel3.Size = new Size(1021, 77);
            panel3.TabIndex = 22;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(20, 17);
            label9.Name = "label9";
            label9.Size = new Size(139, 42);
            label9.TabIndex = 21;
            label9.Text = "Eventos";
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(0, 192, 0);
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button4.ForeColor = Color.Transparent;
            button4.Location = new Point(287, 723);
            button4.Name = "button4";
            button4.Size = new Size(222, 55);
            button4.TabIndex = 24;
            button4.Text = "Eventos Monetários";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // panel17
            // 
            panel17.BackColor = Color.White;
            panel17.Controls.Add(button18);
            panel17.Controls.Add(label37);
            panel17.Controls.Add(panel19);
            panel17.Controls.Add(label32);
            panel17.Controls.Add(dataGridView6);
            panel17.Controls.Add(textBox7);
            panel17.Controls.Add(label36);
            panel17.Controls.Add(label31);
            panel17.Controls.Add(dataGridView5);
            panel17.Controls.Add(button17);
            panel17.Controls.Add(panel18);
            panel17.Location = new Point(353, 9);
            panel17.Name = "panel17";
            panel17.Size = new Size(1077, 824);
            panel17.TabIndex = 29;
            // 
            // button18
            // 
            button18.BackColor = Color.FromArgb(0, 192, 0);
            button18.FlatStyle = FlatStyle.Flat;
            button18.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button18.ForeColor = Color.Transparent;
            button18.Location = new Point(104, 650);
            button18.Name = "button18";
            button18.Size = new Size(222, 55);
            button18.TabIndex = 28;
            button18.Text = "Adicionar pulseiras";
            button18.UseVisualStyleBackColor = false;
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.BackColor = Color.Transparent;
            label37.Font = new Font("Franklin Gothic Medium", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label37.ForeColor = Color.Black;
            label37.Location = new Point(104, 595);
            label37.Name = "label37";
            label37.Size = new Size(217, 30);
            label37.TabIndex = 29;
            label37.Text = "Adicionar Pulseiras:";
            // 
            // panel19
            // 
            panel19.BackColor = Color.Transparent;
            panel19.BackgroundImage = Properties.Resources.top_folder;
            panel19.Location = new Point(29, 549);
            panel19.Name = "panel19";
            panel19.Size = new Size(1021, 10);
            panel19.TabIndex = 24;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(581, 175);
            label32.Name = "label32";
            label32.Size = new Size(96, 25);
            label32.TabIndex = 30;
            label32.Text = "Nº Evento:";
            // 
            // dataGridView6
            // 
            dataGridView6.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView6.Location = new Point(581, 232);
            dataGridView6.Name = "dataGridView6";
            dataGridView6.RowHeadersWidth = 62;
            dataGridView6.Size = new Size(453, 177);
            dataGridView6.TabIndex = 29;
            dataGridView6.CellContentClick += dataGridView6_CellContentClick;
            // 
            // textBox7
            // 
            textBox7.BackColor = SystemColors.ActiveBorder;
            textBox7.Location = new Point(683, 172);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(138, 31);
            textBox7.TabIndex = 28;
            textBox7.TextChanged += textBox7_TextChanged;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(581, 131);
            label36.Name = "label36";
            label36.Size = new Size(203, 25);
            label36.TabIndex = 28;
            label36.Text = "Ver pulseiras por evento";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(107, 192);
            label31.Name = "label31";
            label31.Size = new Size(80, 25);
            label31.TabIndex = 18;
            label31.Text = "Pulseiras";
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(104, 232);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.RowHeadersWidth = 62;
            dataGridView5.Size = new Size(304, 177);
            dataGridView5.TabIndex = 19;
            dataGridView5.CellContentClick += dataGridView5_CellContentClick;
            // 
            // button17
            // 
            button17.Location = new Point(161, 436);
            button17.Name = "button17";
            button17.Size = new Size(173, 34);
            button17.TabIndex = 20;
            button17.Text = "Atualizar pulseiras";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // panel18
            // 
            panel18.BackColor = Color.Transparent;
            panel18.BackgroundImage = Properties.Resources.top_folder;
            panel18.Controls.Add(label33);
            panel18.Location = new Point(29, 28);
            panel18.Name = "panel18";
            panel18.Size = new Size(1021, 77);
            panel18.TabIndex = 22;
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.BackColor = Color.Transparent;
            label33.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label33.ForeColor = Color.White;
            label33.Location = new Point(20, 17);
            label33.Name = "label33";
            label33.Size = new Size(159, 42);
            label33.TabIndex = 21;
            label33.Text = "Pulseiras";
            // 
            // panel15
            // 
            panel15.BackColor = Color.White;
            panel15.Controls.Add(button22);
            panel15.Controls.Add(button21);
            panel15.Controls.Add(button11);
            panel15.Controls.Add(label30);
            panel15.Controls.Add(dataGridView4);
            panel15.Controls.Add(textBox9);
            panel15.Controls.Add(label34);
            panel15.Controls.Add(button13);
            panel15.Controls.Add(button14);
            panel15.Controls.Add(panel16);
            panel15.Controls.Add(button15);
            panel15.Location = new Point(350, 12);
            panel15.Name = "panel15";
            panel15.Size = new Size(1077, 824);
            panel15.TabIndex = 28;
            // 
            // button22
            // 
            button22.Location = new Point(43, 565);
            button22.Name = "button22";
            button22.Size = new Size(173, 34);
            button22.TabIndex = 29;
            button22.Text = "Editar worker";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button21
            // 
            button21.Location = new Point(870, 565);
            button21.Name = "button21";
            button21.Size = new Size(173, 34);
            button21.TabIndex = 28;
            button21.Text = "Eliminar worker ";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // button11
            // 
            button11.BackColor = Color.FromArgb(0, 192, 0);
            button11.FlatStyle = FlatStyle.Flat;
            button11.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button11.ForeColor = Color.Transparent;
            button11.Location = new Point(528, 167);
            button11.Name = "button11";
            button11.Size = new Size(106, 34);
            button11.TabIndex = 27;
            button11.Text = "Procurar";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(32, 170);
            label30.Name = "label30";
            label30.Size = new Size(137, 25);
            label30.TabIndex = 18;
            label30.Text = "Procurar worker";
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(29, 210);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowHeadersWidth = 62;
            dataGridView4.Size = new Size(1021, 340);
            dataGridView4.TabIndex = 19;
            dataGridView4.CellContentClick += dataGridView4_CellContentClick;
            // 
            // textBox9
            // 
            textBox9.BackColor = SystemColors.ActiveBorder;
            textBox9.Location = new Point(175, 167);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(339, 31);
            textBox9.TabIndex = 17;
            textBox9.TextChanged += textBox9_TextChanged;
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label34.Location = new Point(431, 677);
            label34.Name = "label34";
            label34.Size = new Size(172, 23);
            label34.TabIndex = 26;
            label34.Text = "Detalhes de workers:";
            // 
            // button13
            // 
            button13.Location = new Point(440, 565);
            button13.Name = "button13";
            button13.Size = new Size(173, 34);
            button13.TabIndex = 20;
            button13.Text = "Atualizar workers";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.BackColor = Color.FromArgb(0, 192, 0);
            button14.FlatStyle = FlatStyle.Flat;
            button14.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button14.ForeColor = Color.Transparent;
            button14.Location = new Point(550, 723);
            button14.Name = "button14";
            button14.Size = new Size(222, 55);
            button14.TabIndex = 25;
            button14.Text = "Externos";
            button14.UseVisualStyleBackColor = false;
            // 
            // panel16
            // 
            panel16.BackColor = Color.Transparent;
            panel16.BackgroundImage = Properties.Resources.top_folder;
            panel16.Controls.Add(label35);
            panel16.Location = new Point(29, 28);
            panel16.Name = "panel16";
            panel16.Size = new Size(1021, 77);
            panel16.TabIndex = 22;
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.BackColor = Color.Transparent;
            label35.Font = new Font("Franklin Gothic Medium", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label35.ForeColor = Color.White;
            label35.Location = new Point(20, 17);
            label35.Name = "label35";
            label35.Size = new Size(147, 42);
            label35.TabIndex = 21;
            label35.Text = "Workers";
            // 
            // button15
            // 
            button15.BackColor = Color.FromArgb(0, 192, 0);
            button15.FlatStyle = FlatStyle.Flat;
            button15.Font = new Font("Franklin Gothic Medium", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button15.ForeColor = Color.Transparent;
            button15.Location = new Point(287, 723);
            button15.Name = "button15";
            button15.Size = new Size(222, 55);
            button15.TabIndex = 24;
            button15.Text = "Membros";
            button15.UseVisualStyleBackColor = false;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // sqlCommand2
            // 
            sqlCommand2.CommandTimeout = 30;
            sqlCommand2.EnableOptimizedParameterBinding = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1440, 846);
            Controls.Add(panel4);
            Controls.Add(panel11);
            Controls.Add(panel6);
            Controls.Add(panel20);
            Controls.Add(panel2);
            Controls.Add(panel15);
            Controls.Add(panel17);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel20.ResumeLayout(false);
            panel20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView8).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView7).EndInit();
            panel22.ResumeLayout(false);
            panel22.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel17.ResumeLayout(false);
            panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView6).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            panel18.ResumeLayout(false);
            panel18.PerformLayout();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label4;
        private Button button1;
        private Button button2;
        private Panel panel2;
        private PictureBox pictureBox2;
        private ContextMenuStrip contextMenuStrip1;
        private Label label5;
        private Label label8;
        private Label label7;
        private Label label6;
        private PictureBox pictureBox3;
        private Panel panel5;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand2;
        private Button button3;
        private DataGridView dataGridView1;
        private Label label9;
        private Panel panel3;
        private Label label11;
        private Panel panel4;
        private Panel panel6;
        private DataGridView dataGridView2;
        private Button button6;
        private Panel panel7;
        private Label label12;
        private Button button5;
        private Button button4;
        private Label label10;
        private Panel panel8;
        private Button button7;
        private Label label13;
        private TextBox textBox4;
        private Label label14;
        private TextBox textBox5;
        private Label label16;
        private Label label17;
        private Button button9;
        private Label label15;
        private Panel panel10;
        private Panel panel9;
        private Button button8;
        private Panel panel11;
        private Button button10;
        private Label label18;
        private Panel panel13;
        private Label label19;
        private Label label20;
        private Label label21;
        private TextBox textBox6;
        private Label label22;
        private DataGridView dataGridView3;
        private Button button12;
        private Panel panel14;
        private Label label23;
        private Label label29;
        private Panel panel12;
        private Label label27;
        private Label label28;
        private Label label25;
        private Label label26;
        private Label label24;
        private Label label31;
        private TextBox textBox8;
        private Label label33;
        private Panel panel15;
        private Button button11;
        private Label label30;
        private DataGridView dataGridView4;
        private TextBox textBox9;
        private Label label34;
        private Button button13;
        private Button button14;
        private Panel panel16;
        private Label label35;
        private Button button15;
        private Panel panel17;
        private TextBox textBox7;
        private Label label36;
        private DataGridView dataGridView5;
        private Button button17;
        private Panel panel18;
        private Label label32;
        private DataGridView dataGridView6;
        private Button button18;
        private Label label37;
        private Panel panel19;
        private Panel panel20;
        private Button button16;
        private Label label38;
        private Panel panel21;
        private DataGridView dataGridView7;
        private Panel panel22;
        private Label label42;
        private Label label40;
        private Label label39;
        private DataGridView dataGridView8;
        private Button button20;
        private Button button19;
        private Button button22;
        private Button button21;
        private Label label45;
        private Label label44;
        private Button button23;
        private Button button24;
    }
}