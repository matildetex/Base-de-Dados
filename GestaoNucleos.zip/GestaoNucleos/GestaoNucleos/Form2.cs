﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestaoNucleos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox_nevento_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_addeventoNaoMon_Click(object sender, EventArgs e)
        {
            // Get the event number and worker's n_CC from the text boxes
            int numero = int.Parse(textBox_nevento.Text);
            string n_CC = textBox4.Text;

            // Call the method to delete the worker
            DeleteWorker(numero, n_CC);

            // Clear the text boxes
            textBox_nevento.Text = "";
            textBox4.Text = "";
        }

        private void DeleteWorker(int numero, string n_CC)
        {
            // Same code as before to connect to the database and execute the stored procedure
            string connectionString = "Data Source=mednat.ieeta.pt\\SQLSERVER,8101;Initial Catalog=p10g5;uid=p10g5;password=Rissois4@rroz;encrypt=false";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand("DelTrabalhador", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@numero", numero);
                    command.Parameters.AddWithValue("@n_CC", n_CC);

                    command.ExecuteNonQuery();

                    MessageBox.Show("Worker deleted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }




    }
}
