﻿namespace GestaoNucleos
{
    partial class EliminarTrabalhador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label_addeventonaomonetario = new Label();
            pictureBox1 = new PictureBox();
            textBox_nomevento = new TextBox();
            textBox_nevento = new TextBox();
            label_nomevento = new Label();
            label_numeroevento = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            button_addeventoNaoMon = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label_addeventonaomonetario
            // 
            label_addeventonaomonetario.AutoSize = true;
            label_addeventonaomonetario.BackColor = Color.Green;
            label_addeventonaomonetario.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label_addeventonaomonetario.ForeColor = SystemColors.ButtonFace;
            label_addeventonaomonetario.Location = new Point(25, 62);
            label_addeventonaomonetario.Margin = new Padding(4, 0, 4, 0);
            label_addeventonaomonetario.Name = "label_addeventonaomonetario";
            label_addeventonaomonetario.Size = new Size(194, 38);
            label_addeventonaomonetario.TabIndex = 9;
            label_addeventonaomonetario.Text = "Editar worker";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Green;
            pictureBox1.Location = new Point(-18, 13);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1001, 119);
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // textBox_nomevento
            // 
            textBox_nomevento.Location = new Point(167, 241);
            textBox_nomevento.Margin = new Padding(4);
            textBox_nomevento.Name = "textBox_nomevento";
            textBox_nomevento.Size = new Size(245, 31);
            textBox_nomevento.TabIndex = 17;
            textBox_nomevento.TextChanged += textBox_nomevento_TextChanged;
            // 
            // textBox_nevento
            // 
            textBox_nevento.Location = new Point(167, 168);
            textBox_nevento.Margin = new Padding(4);
            textBox_nevento.Name = "textBox_nevento";
            textBox_nevento.Size = new Size(245, 31);
            textBox_nevento.TabIndex = 16;
            textBox_nevento.TextChanged += textBox_nevento_TextChanged;
            // 
            // label_nomevento
            // 
            label_nomevento.AutoSize = true;
            label_nomevento.Location = new Point(79, 241);
            label_nomevento.Margin = new Padding(4, 0, 4, 0);
            label_nomevento.Name = "label_nomevento";
            label_nomevento.Size = new Size(65, 25);
            label_nomevento.TabIndex = 15;
            label_nomevento.Text = "Nome:";
            // 
            // label_numeroevento
            // 
            label_numeroevento.AutoSize = true;
            label_numeroevento.Location = new Point(80, 172);
            label_numeroevento.Margin = new Padding(4, 0, 4, 0);
            label_numeroevento.Name = "label_numeroevento";
            label_numeroevento.Size = new Size(64, 25);
            label_numeroevento.TabIndex = 14;
            label_numeroevento.Text = "Nº CC:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(167, 323);
            textBox2.Margin = new Padding(4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(245, 31);
            textBox2.TabIndex = 20;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(66, 327);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(78, 25);
            label2.TabIndex = 18;
            label2.Text = "Morada:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(589, 323);
            textBox1.Margin = new Padding(4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(245, 31);
            textBox1.TabIndex = 26;
            textBox1.TextChanged += textBox1_TextChanged_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(500, 327);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(63, 25);
            label1.TabIndex = 25;
            label1.Text = "Horas:";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(589, 241);
            textBox3.Margin = new Padding(4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(245, 31);
            textBox3.TabIndex = 24;
            textBox3.TextChanged += textBox3_TextChanged_1;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(589, 168);
            textBox4.Margin = new Padding(4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(245, 31);
            textBox4.TabIndex = 23;
            textBox4.TextChanged += textBox4_TextChanged_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(505, 244);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(58, 25);
            label3.TabIndex = 22;
            label3.Text = "Email:";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(469, 172);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.RightToLeft = RightToLeft.No;
            label4.Size = new Size(94, 25);
            label4.TabIndex = 21;
            label4.Text = "Telemóvel:";
            // 
            // button_addeventoNaoMon
            // 
            button_addeventoNaoMon.BackColor = Color.Green;
            button_addeventoNaoMon.ForeColor = SystemColors.ButtonFace;
            button_addeventoNaoMon.Location = new Point(263, 400);
            button_addeventoNaoMon.Margin = new Padding(4);
            button_addeventoNaoMon.Name = "button_addeventoNaoMon";
            button_addeventoNaoMon.Size = new Size(315, 36);
            button_addeventoNaoMon.TabIndex = 27;
            button_addeventoNaoMon.Text = "Editar worker";
            button_addeventoNaoMon.UseVisualStyleBackColor = false;
            button_addeventoNaoMon.Click += button_addeventoNaoMon_Click;
            // 
            // EliminarTrabalhador
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(868, 462);
            Controls.Add(button_addeventoNaoMon);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(textBox3);
            Controls.Add(textBox4);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox_nomevento);
            Controls.Add(textBox_nevento);
            Controls.Add(label_nomevento);
            Controls.Add(label_numeroevento);
            Controls.Add(label_addeventonaomonetario);
            Controls.Add(pictureBox1);
            Name = "EliminarTrabalhador";
            Text = "AdicionarEventoMonetario";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label_addeventonaomonetario;
        private PictureBox pictureBox1;
        private TextBox textBox_nomevento;
        private TextBox textBox_nevento;
        private Label label_nomevento;
        private Label label_numeroevento;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label3;
        private Label label4;
        private Button button_addeventoNaoMon;
    }
}