using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Modal2
{
    public partial class Modal1 : Form
    {
        public Modal1()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label_titulo_eventonaomonetario_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button_addeventoNaoMon_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=mednat.ieeta.pt\\SQLSERVER,8101;Initial Catalog=p10g5;uid=p10g5;password=Rissois4@rroz;encrypt=false";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand("GestaoNucleos.AddEventoNaoMonetario", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@numero", SqlDbType.Int).Direction = ParameterDirection.Output;
                    command.Parameters.AddWithValue("@nome", textBox_nomevento.Text);
                    command.Parameters.AddWithValue("@local", textBox_local.Text);
                    command.Parameters.AddWithValue("@tipo", comboBox_tipo.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@area", comboBox_area.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@n_participantes", (int)numericUpDown_participantes.Value);
                    command.Parameters.AddWithValue("@n_trabalhadores", (int)numericUpDown_trab.Value);
                    command.Parameters.AddWithValue("@data", dateTimePicker_data.Value);
                    command.Parameters.AddWithValue("@Sponsor_CC", textBox_sponsorCC.Text);

                    command.ExecuteNonQuery();

                    int numero = (int)command.Parameters["@numero"].Value;

                    MessageBox.Show($"Evento N�o Monet�rio Adicionado com Sucesso.\nN�mero do Evento: {numero}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"N�o foi poss�vel adicionar o Evento N�o Monet�rio.\n\nMensagem de Erro: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }


        private void label_numeroevento_Click(object sender, EventArgs e)
        {

        }

        private void textBox_nevento_TextChanged(object sender, EventArgs e)
        {
        }

        private void label_nomevento_Click(object sender, EventArgs e)
        {
        }

        private void textBox_nomevento_TextChanged(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}