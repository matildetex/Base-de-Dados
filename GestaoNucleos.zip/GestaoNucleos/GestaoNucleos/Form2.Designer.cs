﻿namespace GestaoNucleos
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label_addeventonaomonetario = new Label();
            pictureBox1 = new PictureBox();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox_nevento = new TextBox();
            label_numeroevento = new Label();
            button_addeventoNaoMon = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label_addeventonaomonetario
            // 
            label_addeventonaomonetario.AutoSize = true;
            label_addeventonaomonetario.BackColor = Color.Green;
            label_addeventonaomonetario.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label_addeventonaomonetario.ForeColor = SystemColors.ButtonFace;
            label_addeventonaomonetario.Location = new Point(32, 62);
            label_addeventonaomonetario.Margin = new Padding(4, 0, 4, 0);
            label_addeventonaomonetario.Name = "label_addeventonaomonetario";
            label_addeventonaomonetario.Size = new Size(225, 38);
            label_addeventonaomonetario.TabIndex = 11;
            label_addeventonaomonetario.Text = "Eliminar worker";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Green;
            pictureBox1.Location = new Point(-11, 13);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1001, 119);
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(530, 233);
            textBox4.Margin = new Padding(4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(245, 31);
            textBox4.TabIndex = 27;
            textBox4.TextChanged += textBox4_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(436, 236);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.RightToLeft = RightToLeft.No;
            label4.Size = new Size(70, 25);
            label4.TabIndex = 26;
            label4.Text = "Evento:";
            // 
            // textBox_nevento
            // 
            textBox_nevento.Location = new Point(108, 233);
            textBox_nevento.Margin = new Padding(4);
            textBox_nevento.Name = "textBox_nevento";
            textBox_nevento.Size = new Size(245, 31);
            textBox_nevento.TabIndex = 25;
            textBox_nevento.TextChanged += textBox_nevento_TextChanged;
            // 
            // label_numeroevento
            // 
            label_numeroevento.AutoSize = true;
            label_numeroevento.Location = new Point(21, 237);
            label_numeroevento.Margin = new Padding(4, 0, 4, 0);
            label_numeroevento.Name = "label_numeroevento";
            label_numeroevento.Size = new Size(64, 25);
            label_numeroevento.TabIndex = 24;
            label_numeroevento.Text = "Nº CC:";
            // 
            // button_addeventoNaoMon
            // 
            button_addeventoNaoMon.BackColor = Color.Green;
            button_addeventoNaoMon.ForeColor = SystemColors.ButtonFace;
            button_addeventoNaoMon.Location = new Point(246, 342);
            button_addeventoNaoMon.Margin = new Padding(4);
            button_addeventoNaoMon.Name = "button_addeventoNaoMon";
            button_addeventoNaoMon.Size = new Size(315, 36);
            button_addeventoNaoMon.TabIndex = 28;
            button_addeventoNaoMon.Text = "Eliminar";
            button_addeventoNaoMon.UseVisualStyleBackColor = false;
            button_addeventoNaoMon.Click += button_addeventoNaoMon_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button_addeventoNaoMon);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox_nevento);
            Controls.Add(label_numeroevento);
            Controls.Add(label_addeventonaomonetario);
            Controls.Add(pictureBox1);
            Name = "Form2";
            Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label_addeventonaomonetario;
        private PictureBox pictureBox1;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox_nevento;
        private Label label_numeroevento;
        private Button button_addeventoNaoMon;
    }
}